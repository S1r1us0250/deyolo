---
description: Accelerate your AI development with the Ultralytics HUB Training Session. High-performance training of object detection models.
keywords: YOLOv5, object detection, HUBTrainingSession, custom models, Ultralytics Docs
---

## HUBTrainingSession
---
### ::: ultralytics.hub.session.HUBTrainingSession
<br><br>
