---
description: Create a custom dataset of mixed and oriented rectangular objects with Ultralytics YOLO's MixAndRectDataset.
keywords: Ultralytics YOLO, MixAndRectDataset, dataset wrapper, image-level annotations, object-level annotations, rectangular object detection
---

## MixAndRectDataset
---
### ::: ultralytics.yolo.data.dataset_wrappers.MixAndRectDataset
<br><br>
