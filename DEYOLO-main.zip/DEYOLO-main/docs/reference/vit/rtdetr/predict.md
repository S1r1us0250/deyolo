---
description: Learn about the RTDETRPredictor class and how to use it for vision transformer object detection with Ultralytics YOLO.
keywords: RTDETRPredictor, object detection, vision transformer, Ultralytics YOLO
---

## RTDETRPredictor
---
### ::: ultralytics.vit.rtdetr.predict.RTDETRPredictor
<br><br>