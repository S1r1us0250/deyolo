---
description: Train faster with mixed precision. Learn how to use BaseTrainer with Advanced Mixed Precision to optimize YOLOv3 and YOLOv4 models.
keywords: Ultralytics YOLO, BaseTrainer, object detection models, training guide
---

## BaseTrainer
---
### ::: ultralytics.yolo.engine.trainer.BaseTrainer
<br><br>
