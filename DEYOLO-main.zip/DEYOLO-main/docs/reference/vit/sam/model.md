---
description: Learn about the Ultralytics VIT SAM model for object detection and how it can help streamline your computer vision workflow. Check out the documentation for implementation details and examples.
keywords: Ultralytics, VIT, SAM, object detection, computer vision, deep learning, implementation, examples
---

## SAM
---
### ::: ultralytics.vit.sam.model.SAM
<br><br>