---
description: Explore the Sam module in Ultralytics VIT, a PyTorch-based vision library, and learn how to improve your image classification and segmentation tasks.
keywords: Ultralytics VIT, Sam module, PyTorch vision library, image classification, segmentation tasks
---

## Sam
---
### ::: ultralytics.vit.sam.modules.sam.Sam
<br><br>